<table border="1" cellpadding="5" cellspacing="0">
<caption>Group Members Name and UCID</caption>

  <tr>
    <th>First name</th>
    <th>Last name</th>
    <th>UCID</th>
  </tr>
  <tr>
    <td>Patrick</td>
    <td>Okafor</td>
    <td>30230000</td>
  </tr>
  <tr>
    <td>Ifeanyi</td>
    <td>Afoma</td>
    <td>30230178</td>
  </tr>
  <tr>
    <td>Akachukwu</td>
    <td>Hyacienth</td>
    <td>30198304</td>
  </tr>
  <tr>
    <td>Moses</td>
    <td>Kimiji</td>
    <td>30229997</td>
  </tr>

</table>

<p><b>Lab Objective</b>: The objective of this lab session is to understand the fundamental principle of Least Square Estimation for both linear and nonlinear problem using python programming language, numpy, pandas library, and matplotlib as a computational and visualization tools.

<p> In this project, we were tasked to develop an algorithm for single point positioning (SPP) using measurements from Global Navigation Satellite System (GNSS) and Least Square Estimation process to estimate and optimize the estimated receiver's coordinate and clock biase. This optimization algorithm would be used by Deep-Autolab's self-driving car for its tracking and navigation.
